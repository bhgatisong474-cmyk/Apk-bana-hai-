# ARJIT BOXER v2 (online coach + food photo)

## A) APK banana (phone se, folder upload ki zaroorat nahi)
1. GitHub pe naya repo banao. "Add file -> Upload files" se sirf **project.zip** upload karo (zip ko extract MAT karo) -> Commit.
2. "Add file -> Create new file": naam mein likho `.github/workflows/build-apk.yml` (slash likhne se folder ban jata hai). `build-apk.yml` ka poora text paste karo -> Commit.
3. Actions tab -> "Build ARJIT Boxer APK" khud chalega (ya Run workflow). Green check ke baad run kholo -> Artifacts -> ARJIT-Boxer-APK -> download -> extract -> app-debug.apk install.
Aage jab bhi naya project.zip upload karoge (same naam se replace), APK khud dubara banega.

## B) Internet wala coach (free)
1. aistudio.google.com/apikey se free Gemini API key lo.
2. dash.cloudflare.com -> Workers & Pages -> Create -> "Hello World" worker -> Deploy -> Edit code -> `worker/worker.js` ka text paste -> Deploy.
3. Worker -> Settings -> Variables and Secrets -> Add: `GEMINI_API_KEY` (type Secret) = tumhari key. Deploy.
4. Worker ka URL (https://....workers.dev) copy karo -> app -> My Profile -> Online coach -> paste -> Save & test.
Agar model chalna band ho to Worker mein variable `MODEL` add karke naya Gemini flash model naam do.

## Limits (sach)
- Free tier mein rate limit hoti hai, aur free tier ka data Google use kar sakta hai.
- Food photo se calories/minerals sirf andaza hain, exact nahi.
- Data phone mein hai; uninstall/clear data pe ud sakta hai. Backup button se JSON share karke safe rakho.
- Ye beginner non-contact fitness guide hai, medical advice ya certified coach nahi.
